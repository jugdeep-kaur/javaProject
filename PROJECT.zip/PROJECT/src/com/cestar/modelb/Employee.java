package com.cestar.modelb;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;


@ManagedBean(name="emp")
@RequestScoped
public class Employee {
	
	private int id ;
	private String name ;
	private String contact ;
	private String book_issued;
	private String date_issued ;
	private String date_returned ;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getBook_issued() {
		return book_issued;
	}
	public void setBook_issued(String book_issued) {
		this.book_issued = book_issued;
	}
	public String getDate_issued() {
		return date_issued;
	}
	public void setDate_issued(String date_issued) {
		this.date_issued = date_issued;
	}
	public String getDate_returned() {
		return date_returned;
	}
	public void setDate_returned(String date_returned) {
		this.date_returned = date_returned;
	}
	
	public Employee(int id, String name, String contact, String book_issued, String date_issued, String date_returned) {
		super();
		this.id = id;
		this.name = name;
		this.contact = contact;
		this.book_issued = book_issued;
		this.date_issued = date_issued;
		this.date_returned = date_returned;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", contact=" + contact + ", book_issued=" + book_issued
				+ ", date_issued=" + date_issued + ", date_returned=" + date_returned + "]";
	}
}